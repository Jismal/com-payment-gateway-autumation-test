package com.practise.bdd.step_def.Sort;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SortStepDef {

    @When("^I set sort by filter as \"([^\"]*)\"$")
    public void i_set_sort_by_filter_as(String arg1)  {

    }

    @Then("^I should see all the product in sorted order as \"([^\"]*)\"$")
    public void i_should_see_all_the_product_in_sorted_order_as(String arg1) {

    }

}
